package A;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResponceServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse responce)
			throws ServletException, IOException {
		responce.setHeader("ss", "ads");//��Ӧͷ�У����ü�
		responce.setHeader("a", "a");//����
		responce.setHeader("content-type", "text/html;charset=utf-8");
		//������Ӧ״̬��
		//responce.sendError(404,"asdasdsadsa");
		//������Ӧʵ��
		responce.getWriter().write("this is st");
		
	
	}
}
