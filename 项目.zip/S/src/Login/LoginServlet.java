package Login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse responce)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
			//��ȡrequest����������
		String str = (String)request.getAttribute("str");
		
		responce.setContentType("text/html;charset=utf-8");
		responce.getWriter().write("<html>");
		responce.getWriter().write("<head>");
		responce.getWriter().write("</head>");
		responce.getWriter().write("<body>");
		if(str!=null){
			responce.getWriter().write("<font color='red' size='5px'>"+str+"</font>");
		}
		responce.getWriter().write("<form action='login2' method='get'>");//action �ύ��ַ  method���ύ��ʽ
		responce.getWriter().write("�û���:<input type='text' name='uname' value='' /></br>");
		responce.getWriter().write("����:<input type='password' name='pwd' value='' /></br>");
		responce.getWriter().write("<input type='submit' value='��¼' /></br>");
		responce.getWriter().write("</form>");
		responce.getWriter().write("</body>");
		responce.getWriter().write("</html>");
	}
}		
