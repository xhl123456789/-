package Login;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojo.User;

public class MainServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//������������ʽ
		req.setCharacterEncoding("utf-8");
		//������Ӧ�����ʽ
		resp.setContentType("text/html;charset=utf-8");
		
		HttpSession hs = req.getSession();
		User user = (User)hs.getAttribute("user");
		
		ServletContext sc = this.getServletContext();
		int nums = (Integer)sc.getAttribute("nums");
		resp.getWriter().write("<html>");
		resp.getWriter().write("<head>");
		resp.getWriter().write("");
		resp.getWriter().write("</head>");
		resp.getWriter().write("<body>");
		resp.getWriter().write("<H3>��ӭ"+user.getUname()+"���ʹ���ϵͳ</h3></br>");
		resp.getWriter().write("<H5>��"+nums+"�η��ʹ���ϵͳ</h5>");
		resp.getWriter().write("<form action='show' method='post'>");
		resp.getWriter().write("<input type='submit' value='������Ϣ' /></br>");
		resp.getWriter().write("</form>");
		resp.getWriter().write("</body>");
		
	}
}
