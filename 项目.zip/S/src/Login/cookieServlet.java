package Login;


import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojo.User;

import Service.CheckUser;
import ServiceImp.LoginServiceImp;

public class cookieServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		
		Cookie[] cks = req.getCookies();
		if(cks != null){
			String uid = "";
			for(Cookie c : cks){
				if("uid".equals(c.getName())){
					uid=c.getValue();
				}
				if("".equals(uid)){
					req.getRequestDispatcher("login").forward(req, resp);
					return;
				}else{
					//���UID�û���Ϣ
					CheckUser cu = new LoginServiceImp();
					User u = cu.checkUidService(uid);
					if(u!=null){
						req.getSession().setAttribute("user", u);
						ServletContext sc = this.getServletConfig().getServletContext();
						if(sc.getAttribute("nums") == null){
							int nums = 0;
							sc.setAttribute("nums", nums);
						}else{
							int nums =Integer.parseInt((String)sc.getAttribute("nums"));
							nums+=1;
							sc.setAttribute("nums", nums);
						}
						resp.sendRedirect("main");
						return;
					}else{
						req.getRequestDispatcher("login").forward(req, resp);
						return;
					}
				}
			}
			
		}else{
			req.getRequestDispatcher("login").forward(req, resp);
			return;
		}
	}
}
