package Login;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

public class nums extends HttpServlet {
	@Override
	public void destroy() {
		BufferedWriter bw = null;
		FileWriter fw = null;
		ServletContext sc = this.getServletContext();
		int nums = (Integer)sc.getAttribute("nums");
		String path = sc.getRealPath("/WebRoot/nums/nums.text");
		try{
			fw = new FileWriter(path);
			bw = new BufferedWriter(fw);
			bw.write(nums+"");
			bw.flush();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	@Override
	public void init() throws ServletException {
		String path = this.getServletContext().getRealPath("/WebRoot/nums/nums.text");
		BufferedReader br = null;
		FileReader fr = null;
		try{
			fr = new FileReader(path);
			br = new BufferedReader(fr);
			String nums = br.readLine();
			System.out.println(nums);
			this.getServletContext().setAttribute("nums",nums);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}
}
