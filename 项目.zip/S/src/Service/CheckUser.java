package Service;

import pojo.User;

public interface CheckUser {
	User CheckLoginService(String uname,String pwd);

	User checkUidService(String uid);
}
