package Dao;

import pojo.User;

public interface LoginDao {
	User CheckLoginDao(String uname,String pwd);
	
	User CheckCookieDao(String uid);
}
