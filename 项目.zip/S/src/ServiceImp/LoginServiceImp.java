package ServiceImp;

import pojo.User;
import Dao.DaoImpl.LoginDaoImp;
import Service.CheckUser;

public class LoginServiceImp implements CheckUser {
	LoginDaoImp ldi = new LoginDaoImp();
	@Override
	public User CheckLoginService(String uname, String pwd) {
		
		return ldi.CheckLoginDao(uname, pwd);
	}
	
	
	
	@Override
	public User checkUidService(String uid) {
		
		return ldi.CheckCookieDao(uid);
	}
	
	

}
